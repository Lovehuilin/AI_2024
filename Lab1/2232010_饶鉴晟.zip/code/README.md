# Lab 1

This folder contains three Python code files for Lab 1.

## Files

1. `binary_search.py`: This file contains the implementation of the function of binary search.
2. `matrix_calculation.py`: This file contains the implementation of the function about the addition and multiplication of matrix.
3. `dictionary.py`: This file contains the implementation of the function of reversion of Dictionary.
4. `questions_week2.txt`: This file contains the after class questions of week 2.
5. `file_operation.py`: This file contains the implementation of the exercise of week 2.
